public class EkvidenciaValtozo {
    public int index;
    public int erteke;

    EkvidenciaValtozo(int _ind,int _ert){
        index = _ind;
        erteke = _ert;
    }
}
